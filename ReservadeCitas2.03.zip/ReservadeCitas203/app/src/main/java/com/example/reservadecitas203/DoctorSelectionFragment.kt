package com.example.reservadecitas203

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.reservadecitas203.databinding.FragmentDoctorSelectionBinding

class DoctorSelectionFragment : Fragment() {
    private lateinit var binding: FragmentDoctorSelectionBinding
    private val sharedViewModel: SharedViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentDoctorSelectionBinding.inflate(inflater, container, false)

        val doctors = listOf(
            Doctor("Dr. John Doe", "Cardiologia", "Lunes a Viernes"),
            Doctor("Dr. Memin", "Dermatologia", "Lunes a Vierner"),
            Doctor("Dr. Pedro Fernandez", "Pediatria", "Sabados y Domingos"),
            Doctor("Dr. Luis", "Neurologo", "Sabados y Domingos"),
            Doctor("Dra. Silvia", "Quiropractica", "Martes a Domingos"),
            Doctor("Dr. Fisher", "Neumologo", "Jueves a Domingo"),
            Doctor("Dr. Aldo", "Gastroenterologo", "Lunes a Miercoles"),
            Doctor("Dr. Alfredo", "Medico General", "Miercoles a Domingo"),
            Doctor("Dra. Josefina", "Cirugana Plastica", "Jueves"),

        )

        val adapter = DoctorAdapter(doctors) { doctor ->
            sharedViewModel.selectDoctor(doctor)
            (activity as MainActivity).navigateToAppointmentDetails()
        }

        binding.recyclerViewDoctors.layoutManager = LinearLayoutManager(context)
        binding.recyclerViewDoctors.adapter = adapter

        return binding.root
    }
}